# Operating Systems Lab — Assignment 9 Report

## Q1: Printing a process page table

Added the `vmprint()` system call and traversed only user page-directory entries below `KERNBASE`. The output shows each present user page's virtual address, physical frame address, and Present/Writable/User flags, followed by the number of valid user pages and user page-table pages. `pttest` prints the page table before and after reserving four pages with `sbrk`. Because the final implementation uses lazy allocation, it writes one byte to each of the four reserved pages before the second print; this produces four newly mapped pages.

## Q2: Lazy allocation and page faults

Changed positive `sbrk` calls to reserve virtual address space without allocating every physical page immediately. On a valid user page fault below the process's reserved size, the kernel allocates a physical page, clears it to zero, maps it writable/user-accessible, increments the process's fault counter, and resumes the process. Invalid addresses and faults on existing protected mappings kill only the faulting process. `copyuvm` and `deallocuvm` tolerate unmapped holes. `faulttest` reserves 32 pages, writes to five distinct aligned pages, reads the `getfaults()` counter, and checks invalid access in a child process.

## Q3: FIFO and LRU page replacement

Implemented FIFO using a circular replacement pointer and LRU using the most-recently-used timestamps of resident pages. For every reference, the program prints the frame contents and marks the access as a hit or fault. It then prints faults, hits, and hit ratio for 3, 4, and 5 frames. For the required reference string with three frames, the expected counts are FIFO = 15 and LRU = 12.

## Test evidence

Build validation completed with `make` and `make fs.img`. QEMU runtime evidence is intentionally left for capture on the submission machine because QEMU was unavailable in the packaging environment. Attach screenshots of `pttest`, `faulttest`, and `pagerepl` after running them on xv6; do not treat the expected output notes as captured logs.
