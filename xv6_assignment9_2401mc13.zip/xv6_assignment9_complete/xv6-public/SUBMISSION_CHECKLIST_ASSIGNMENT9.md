# Assignment 9 submission checklist

- [x] Kernel source modifications and comments (`vm.c`, `trap.c`, `proc.c`, `proc.h`, `sysproc.c`, `syscall.c`, `syscall.h`, `defs.h`, `user.h`, `usys.S`).
- [x] `pttest.c`.
- [x] `faulttest.c`.
- [x] `pagerepl.c`.
- [x] Makefile integration for all three programs.
- [x] One-page report draft (`REPORT_ASSIGNMENT9.md`).
- [x] Build verified in the packaging environment.
- [ ] Run `pttest` in QEMU and attach a genuine terminal screenshot.
- [ ] Run `faulttest` in QEMU and attach a genuine terminal screenshot.
- [ ] Run `pagerepl` with the assignment string and attach a genuine terminal screenshot.

Runtime screenshots are deliberately not simulated or included as if they were real captures.
