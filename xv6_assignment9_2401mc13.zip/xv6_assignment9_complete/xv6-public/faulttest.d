faulttest.o: faulttest.c /usr/include/stdc-predef.h types.h user.h
