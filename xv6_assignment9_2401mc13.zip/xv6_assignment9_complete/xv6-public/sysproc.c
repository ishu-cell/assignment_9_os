#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;
  struct proc *p = myproc();

  if(argint(0, &n) < 0)
    return -1;
  addr = p->sz;

  // Assignment 9: positive sbrk reserves virtual space only. Physical
  // pages are allocated by the page-fault handler on first access.
  if(n > 0){
    if(p->sz >= KERNBASE || (uint)n >= KERNBASE - p->sz)
      return -1;
    p->sz += n;
  } else if(n < 0){
    // Shrinking still uses the normal VM path; deallocuvm now skips holes.
    if((uint)(-(n + 1)) + 1 > p->sz)
      return -1;
    if(growproc(n) < 0)
      return -1;
  }
  return addr;
}

// Assignment 9: expose the number of lazy page faults handled by this process.
int
sys_getfaults(void)
{
  return myproc()->faults;
}

// Assignment 9: print the current process's user page table.
int
sys_vmprint(void)
{
  vmprint();
  return 0;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
