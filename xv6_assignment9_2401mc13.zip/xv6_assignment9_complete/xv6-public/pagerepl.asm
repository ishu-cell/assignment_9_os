
_pagerepl:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  return faults;
}

int
main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  int refs[MAXREF];
  int n, nf, ff, fl, f, faults, hits;

  printf(1, "Page replacement: FIFO and LRU\n");
  printf(1, "Enter frame count for detailed trace (1-%d): ", MAXFRAMES);
  if(gets(line, sizeof(line)) == 0){
  10:	8d 9d 58 fd ff ff    	lea    -0x2a8(%ebp),%ebx
{
  16:	51                   	push   %ecx
  17:	81 ec b0 02 00 00    	sub    $0x2b0,%esp
  printf(1, "Page replacement: FIFO and LRU\n");
  1d:	68 84 0e 00 00       	push   $0xe84
  22:	6a 01                	push   $0x1
  24:	e8 37 0a 00 00       	call   a60 <printf>
  printf(1, "Enter frame count for detailed trace (1-%d): ", MAXFRAMES);
  29:	83 c4 0c             	add    $0xc,%esp
  2c:	6a 0a                	push   $0xa
  2e:	68 a4 0e 00 00       	push   $0xea4
  33:	6a 01                	push   $0x1
  35:	e8 26 0a 00 00       	call   a60 <printf>
  if(gets(line, sizeof(line)) == 0){
  3a:	5e                   	pop    %esi
  3b:	5f                   	pop    %edi
  3c:	68 00 01 00 00       	push   $0x100
  41:	53                   	push   %ebx
  42:	e8 49 07 00 00       	call   790 <gets>
  47:	83 c4 10             	add    $0x10,%esp
  4a:	85 c0                	test   %eax,%eax
  4c:	0f 84 80 02 00 00    	je     2d2 <main+0x2d2>
    printf(1, "Input error\n");
    exit();
  }
  nf = atoi(line);
  52:	83 ec 0c             	sub    $0xc,%esp
  55:	53                   	push   %ebx
  56:	e8 f5 07 00 00       	call   850 <atoi>
  if(nf < 1 || nf > MAXFRAMES){
  5b:	83 c4 10             	add    $0x10,%esp
  nf = atoi(line);
  5e:	89 85 4c fd ff ff    	mov    %eax,-0x2b4(%ebp)
  if(nf < 1 || nf > MAXFRAMES){
  64:	83 e8 01             	sub    $0x1,%eax
  67:	83 f8 09             	cmp    $0x9,%eax
  6a:	0f 87 91 00 00 00    	ja     101 <main+0x101>
    printf(1, "Invalid frame count\n");
    exit();
  }

  printf(1, "Enter space-separated reference string (up to %d pages):\n", MAXREF);
  70:	50                   	push   %eax
  71:	6a 64                	push   $0x64
  73:	68 d4 0e 00 00       	push   $0xed4
  78:	6a 01                	push   $0x1
  7a:	e8 e1 09 00 00       	call   a60 <printf>
  if(gets(line, sizeof(line)) == 0){
  7f:	58                   	pop    %eax
  80:	5a                   	pop    %edx
  81:	68 00 01 00 00       	push   $0x100
  86:	53                   	push   %ebx
  87:	e8 04 07 00 00       	call   790 <gets>
  8c:	83 c4 10             	add    $0x10,%esp
  8f:	85 c0                	test   %eax,%eax
  91:	0f 84 3b 02 00 00    	je     2d2 <main+0x2d2>
  int i = 0, n = 0, value;
  97:	31 ff                	xor    %edi,%edi
  99:	31 d2                	xor    %edx,%edx
  9b:	be 13 00 80 00       	mov    $0x800013,%esi
  a0:	89 bd 50 fd ff ff    	mov    %edi,-0x2b0(%ebp)
  while(s[i] != 0 && n < MAXREF){
  a6:	80 bd 58 fd ff ff 00 	cmpb   $0x0,-0x2a8(%ebp)
  ad:	75 14                	jne    c3 <main+0xc3>
  af:	eb 3d                	jmp    ee <main+0xee>
  b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
  bf:	00 
      i++;
  c0:	83 c2 01             	add    $0x1,%edx
    while(s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')
  c3:	0f b6 04 13          	movzbl (%ebx,%edx,1),%eax
  c7:	8d 48 f7             	lea    -0x9(%eax),%ecx
  ca:	80 f9 17             	cmp    $0x17,%cl
  cd:	77 49                	ja     118 <main+0x118>
  cf:	0f a3 ce             	bt     %ecx,%esi
  d2:	72 ec                	jb     c0 <main+0xc0>
      i++;
  d4:	83 c2 01             	add    $0x1,%edx
  while(s[i] != 0 && n < MAXREF){
  d7:	80 bc 15 58 fd ff ff 	cmpb   $0x0,-0x2a8(%ebp,%edx,1)
  de:	00 
  df:	75 e2                	jne    c3 <main+0xc3>
    printf(1, "Input error\n");
    exit();
  }
  n = parse_refs(line, refs);
  if(n <= 0){
  e1:	83 bd 50 fd ff ff 00 	cmpl   $0x0,-0x2b0(%ebp)
  e8:	0f 85 be 00 00 00    	jne    1ac <main+0x1ac>
    printf(1, "No references were entered\n");
  ee:	56                   	push   %esi
  ef:	56                   	push   %esi
  f0:	68 39 0e 00 00       	push   $0xe39
  f5:	6a 01                	push   $0x1
  f7:	e8 64 09 00 00       	call   a60 <printf>
    exit();
  fc:	e8 d2 07 00 00       	call   8d3 <exit>
    printf(1, "Invalid frame count\n");
 101:	51                   	push   %ecx
 102:	51                   	push   %ecx
 103:	68 24 0e 00 00       	push   $0xe24
 108:	6a 01                	push   $0x1
 10a:	e8 51 09 00 00       	call   a60 <printf>
    exit();
 10f:	e8 bf 07 00 00       	call   8d3 <exit>
 114:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(s[i] == 0)
 118:	84 c0                	test   %al,%al
 11a:	74 c5                	je     e1 <main+0xe1>
    value = 0;
 11c:	c7 85 54 fd ff ff 00 	movl   $0x0,-0x2ac(%ebp)
 123:	00 00 00 
    if(s[i] < '0' || s[i] > '9'){
 126:	8d 48 d0             	lea    -0x30(%eax),%ecx
 129:	80 f9 09             	cmp    $0x9,%cl
 12c:	77 a6                	ja     d4 <main+0xd4>
 12e:	89 95 54 fd ff ff    	mov    %edx,-0x2ac(%ebp)
 134:	31 c9                	xor    %ecx,%ecx
 136:	66 90                	xchg   %ax,%ax
 138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 13f:	00 
      value = value * 10 + (s[i] - '0');
 140:	83 e8 30             	sub    $0x30,%eax
 143:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
      i++;
 146:	83 85 54 fd ff ff 01 	addl   $0x1,-0x2ac(%ebp)
      value = value * 10 + (s[i] - '0');
 14d:	0f be c0             	movsbl %al,%eax
 150:	8d 0c 48             	lea    (%eax,%ecx,2),%ecx
      i++;
 153:	8b 85 54 fd ff ff    	mov    -0x2ac(%ebp),%eax
    while(s[i] >= '0' && s[i] <= '9'){
 159:	0f b6 04 03          	movzbl (%ebx,%eax,1),%eax
 15d:	8d 50 d0             	lea    -0x30(%eax),%edx
 160:	80 fa 09             	cmp    $0x9,%dl
 163:	76 db                	jbe    140 <main+0x140>
    refs[n++] = value;
 165:	8b 95 54 fd ff ff    	mov    -0x2ac(%ebp),%edx
 16b:	89 8d 54 fd ff ff    	mov    %ecx,-0x2ac(%ebp)
 171:	8b 8d 50 fd ff ff    	mov    -0x2b0(%ebp),%ecx
 177:	8d 79 01             	lea    0x1(%ecx),%edi
 17a:	89 bd 50 fd ff ff    	mov    %edi,-0x2b0(%ebp)
 180:	8b bd 54 fd ff ff    	mov    -0x2ac(%ebp),%edi
 186:	89 bc 8d 58 fe ff ff 	mov    %edi,-0x1a8(%ebp,%ecx,4)
  while(s[i] != 0 && n < MAXREF){
 18d:	84 c0                	test   %al,%al
 18f:	0f 84 4c ff ff ff    	je     e1 <main+0xe1>
 195:	83 bd 50 fd ff ff 64 	cmpl   $0x64,-0x2b0(%ebp)
 19c:	0f 85 21 ff ff ff    	jne    c3 <main+0xc3>
 1a2:	c7 85 50 fd ff ff 64 	movl   $0x64,-0x2b0(%ebp)
 1a9:	00 00 00 
  }

  ff = fifo(refs, n, nf, 1);
 1ac:	83 ec 0c             	sub    $0xc,%esp
 1af:	8b bd 50 fd ff ff    	mov    -0x2b0(%ebp),%edi
 1b5:	8b b5 4c fd ff ff    	mov    -0x2b4(%ebp),%esi
 1bb:	8d 85 58 fe ff ff    	lea    -0x1a8(%ebp),%eax
 1c1:	6a 01                	push   $0x1
 1c3:	89 f1                	mov    %esi,%ecx
 1c5:	89 fa                	mov    %edi,%edx
 1c7:	e8 34 01 00 00       	call   300 <fifo>
  fl = lru(refs, n, nf, 1);
 1cc:	89 f1                	mov    %esi,%ecx
 1ce:	89 fa                	mov    %edi,%edx
 1d0:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
  ff = fifo(refs, n, nf, 1);
 1d7:	89 c3                	mov    %eax,%ebx
  fl = lru(refs, n, nf, 1);
 1d9:	8d 85 58 fe ff ff    	lea    -0x1a8(%ebp),%eax
 1df:	89 b5 4c fd ff ff    	mov    %esi,-0x2b4(%ebp)
 1e5:	e8 86 02 00 00       	call   470 <lru>
  printf(1, "\nSummary for %d frames and %d references\n", nf, n);
 1ea:	57                   	push   %edi
 1eb:	ff b5 4c fd ff ff    	push   -0x2b4(%ebp)
  fl = lru(refs, n, nf, 1);
 1f1:	89 c6                	mov    %eax,%esi
  printf(1, "\nSummary for %d frames and %d references\n", nf, n);
 1f3:	68 10 0f 00 00       	push   $0xf10
 1f8:	6a 01                	push   $0x1
 1fa:	e8 61 08 00 00       	call   a60 <printf>
  printf(1, "FIFO: faults=%d hits=%d hit ratio=%d%%\n", ff, n-ff, ((n-ff)*100)/n);
 1ff:	89 f9                	mov    %edi,%ecx
 201:	83 c4 14             	add    $0x14,%esp
 204:	29 d9                	sub    %ebx,%ecx
 206:	6b c1 64             	imul   $0x64,%ecx,%eax
 209:	99                   	cltd
 20a:	f7 ff                	idiv   %edi
 20c:	50                   	push   %eax
 20d:	51                   	push   %ecx
 20e:	53                   	push   %ebx
 20f:	68 3c 0f 00 00       	push   $0xf3c
 214:	6a 01                	push   $0x1
 216:	e8 45 08 00 00       	call   a60 <printf>
  printf(1, "LRU : faults=%d hits=%d hit ratio=%d%%\n", fl, n-fl, ((n-fl)*100)/n);
 21b:	89 f9                	mov    %edi,%ecx
 21d:	83 c4 14             	add    $0x14,%esp
 220:	29 f1                	sub    %esi,%ecx
 222:	6b c1 64             	imul   $0x64,%ecx,%eax
 225:	99                   	cltd
 226:	f7 ff                	idiv   %edi
 228:	50                   	push   %eax
 229:	51                   	push   %ecx
 22a:	56                   	push   %esi

  printf(1, "\nComparison table (same reference string)\n");
  printf(1, "Frames  Algorithm  Faults  Hits  HitRatio(%%)\n");
  for(f = 3; f <= 5; f++){
 22b:	89 fe                	mov    %edi,%esi
  printf(1, "LRU : faults=%d hits=%d hit ratio=%d%%\n", fl, n-fl, ((n-fl)*100)/n);
 22d:	68 64 0f 00 00       	push   $0xf64
 232:	6a 01                	push   $0x1
 234:	e8 27 08 00 00       	call   a60 <printf>
  printf(1, "\nComparison table (same reference string)\n");
 239:	83 c4 18             	add    $0x18,%esp
 23c:	68 8c 0f 00 00       	push   $0xf8c
 241:	6a 01                	push   $0x1
 243:	e8 18 08 00 00       	call   a60 <printf>
  printf(1, "Frames  Algorithm  Faults  Hits  HitRatio(%%)\n");
 248:	59                   	pop    %ecx
 249:	5b                   	pop    %ebx
 24a:	68 b8 0f 00 00       	push   $0xfb8
 24f:	6a 01                	push   $0x1
  for(f = 3; f <= 5; f++){
 251:	bb 03 00 00 00       	mov    $0x3,%ebx
  printf(1, "Frames  Algorithm  Faults  Hits  HitRatio(%%)\n");
 256:	e8 05 08 00 00       	call   a60 <printf>
 25b:	83 c4 10             	add    $0x10,%esp
    faults = fifo(refs, n, f, 0);
 25e:	83 ec 0c             	sub    $0xc,%esp
 261:	89 d9                	mov    %ebx,%ecx
 263:	89 f2                	mov    %esi,%edx
    hits = n - faults;
 265:	89 f7                	mov    %esi,%edi
    faults = fifo(refs, n, f, 0);
 267:	6a 00                	push   $0x0
 269:	8d 85 58 fe ff ff    	lea    -0x1a8(%ebp),%eax
 26f:	e8 8c 00 00 00       	call   300 <fifo>
    hits = n - faults;
 274:	29 c7                	sub    %eax,%edi
    faults = fifo(refs, n, f, 0);
 276:	89 c1                	mov    %eax,%ecx
    printf(1, "%d\tFIFO\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
 278:	58                   	pop    %eax
 279:	5a                   	pop    %edx
 27a:	6b c7 64             	imul   $0x64,%edi,%eax
 27d:	99                   	cltd
 27e:	f7 fe                	idiv   %esi
 280:	50                   	push   %eax
 281:	57                   	push   %edi
    faults = lru(refs, n, f, 0);
    hits = n - faults;
 282:	89 f7                	mov    %esi,%edi
    printf(1, "%d\tFIFO\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
 284:	51                   	push   %ecx
 285:	53                   	push   %ebx
 286:	68 55 0e 00 00       	push   $0xe55
 28b:	6a 01                	push   $0x1
 28d:	e8 ce 07 00 00       	call   a60 <printf>
    faults = lru(refs, n, f, 0);
 292:	83 c4 14             	add    $0x14,%esp
 295:	89 d9                	mov    %ebx,%ecx
 297:	89 f2                	mov    %esi,%edx
 299:	6a 00                	push   $0x0
 29b:	8d 85 58 fe ff ff    	lea    -0x1a8(%ebp),%eax
 2a1:	e8 ca 01 00 00       	call   470 <lru>
    hits = n - faults;
 2a6:	29 c7                	sub    %eax,%edi
    faults = lru(refs, n, f, 0);
 2a8:	89 c1                	mov    %eax,%ecx
    printf(1, "%d\tLRU\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
 2aa:	58                   	pop    %eax
 2ab:	5a                   	pop    %edx
 2ac:	6b c7 64             	imul   $0x64,%edi,%eax
 2af:	99                   	cltd
 2b0:	f7 fe                	idiv   %esi
 2b2:	50                   	push   %eax
 2b3:	57                   	push   %edi
 2b4:	51                   	push   %ecx
 2b5:	53                   	push   %ebx
  for(f = 3; f <= 5; f++){
 2b6:	83 c3 01             	add    $0x1,%ebx
    printf(1, "%d\tLRU\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
 2b9:	68 69 0e 00 00       	push   $0xe69
 2be:	6a 01                	push   $0x1
 2c0:	e8 9b 07 00 00       	call   a60 <printf>
  for(f = 3; f <= 5; f++){
 2c5:	83 c4 20             	add    $0x20,%esp
 2c8:	83 fb 06             	cmp    $0x6,%ebx
 2cb:	75 91                	jne    25e <main+0x25e>
  }
  exit();
 2cd:	e8 01 06 00 00       	call   8d3 <exit>
    printf(1, "Input error\n");
 2d2:	53                   	push   %ebx
 2d3:	53                   	push   %ebx
 2d4:	68 17 0e 00 00       	push   $0xe17
 2d9:	6a 01                	push   $0x1
 2db:	e8 80 07 00 00       	call   a60 <printf>
    exit();
 2e0:	e8 ee 05 00 00       	call   8d3 <exit>
 2e5:	66 90                	xchg   %ax,%ax
 2e7:	66 90                	xchg   %ax,%ax
 2e9:	66 90                	xchg   %ax,%ax
 2eb:	66 90                	xchg   %ax,%ax
 2ed:	66 90                	xchg   %ax,%ax
 2ef:	66 90                	xchg   %ax,%ax
 2f1:	66 90                	xchg   %ax,%ax
 2f3:	66 90                	xchg   %ax,%ax
 2f5:	66 90                	xchg   %ax,%ax
 2f7:	66 90                	xchg   %ax,%ax
 2f9:	66 90                	xchg   %ax,%ax
 2fb:	66 90                	xchg   %ax,%ax
 2fd:	66 90                	xchg   %ax,%ax
 2ff:	90                   	nop

00000300 <fifo>:
{
 300:	55                   	push   %ebp
 301:	89 e5                	mov    %esp,%ebp
 303:	57                   	push   %edi
 304:	89 c7                	mov    %eax,%edi
 306:	56                   	push   %esi
 307:	8d 45 c0             	lea    -0x40(%ebp),%eax
 30a:	89 d6                	mov    %edx,%esi
 30c:	53                   	push   %ebx
 30d:	8d 5c 8d c0          	lea    -0x40(%ebp,%ecx,4),%ebx
 311:	83 ec 5c             	sub    $0x5c,%esp
 314:	89 4d ac             	mov    %ecx,-0x54(%ebp)
 317:	83 e1 01             	and    $0x1,%ecx
 31a:	74 24                	je     340 <fifo+0x40>
  for(i = 0; i < nf; i++)
 31c:	8d 45 c4             	lea    -0x3c(%ebp),%eax
    fr[i] = -1;
 31f:	c7 45 c0 ff ff ff ff 	movl   $0xffffffff,-0x40(%ebp)
  for(i = 0; i < nf; i++)
 326:	39 d8                	cmp    %ebx,%eax
 328:	74 2a                	je     354 <fifo+0x54>
 32a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 330:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 337:	00 
 338:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 33f:	00 
    fr[i] = -1;
 340:	c7 00 ff ff ff ff    	movl   $0xffffffff,(%eax)
  for(i = 0; i < nf; i++)
 346:	83 c0 08             	add    $0x8,%eax
    fr[i] = -1;
 349:	c7 40 fc ff ff ff ff 	movl   $0xffffffff,-0x4(%eax)
  for(i = 0; i < nf; i++)
 350:	39 d8                	cmp    %ebx,%eax
 352:	75 ec                	jne    340 <fifo+0x40>
  if(trace)
 354:	8b 45 08             	mov    0x8(%ebp),%eax
 357:	85 c0                	test   %eax,%eax
 359:	0f 85 f7 00 00 00    	jne    456 <fifo+0x156>
  for(i = 0; i < n; i++){
 35f:	8d 04 b7             	lea    (%edi,%esi,4),%eax
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
 362:	c7 45 a8 00 00 00 00 	movl   $0x0,-0x58(%ebp)
 369:	89 45 b4             	mov    %eax,-0x4c(%ebp)
 36c:	c7 45 b0 00 00 00 00 	movl   $0x0,-0x50(%ebp)
 373:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 378:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 37f:	00 
      if(fr[j] == refs[i]){ hit = 1; break; }
 380:	8b 0f                	mov    (%edi),%ecx
 382:	8d 45 c0             	lea    -0x40(%ebp),%eax
 385:	8d 76 00             	lea    0x0(%esi),%esi
 388:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 38f:	00 
 390:	39 08                	cmp    %ecx,(%eax)
 392:	74 3c                	je     3d0 <fifo+0xd0>
    for(j = 0; j < nf; j++)
 394:	83 c0 04             	add    $0x4,%eax
 397:	39 d8                	cmp    %ebx,%eax
 399:	75 f5                	jne    390 <fifo+0x90>
      fr[next] = refs[i];
 39b:	8b 45 b0             	mov    -0x50(%ebp),%eax
    if(trace){
 39e:	8b 75 08             	mov    0x8(%ebp),%esi
      faults++;
 3a1:	83 45 a8 01          	addl   $0x1,-0x58(%ebp)
      fr[next] = refs[i];
 3a5:	89 4c 85 c0          	mov    %ecx,-0x40(%ebp,%eax,4)
      next = (next + 1) % nf;
 3a9:	83 c0 01             	add    $0x1,%eax
 3ac:	99                   	cltd
 3ad:	f7 7d ac             	idivl  -0x54(%ebp)
 3b0:	89 55 b0             	mov    %edx,-0x50(%ebp)
    hit = 0;
 3b3:	31 d2                	xor    %edx,%edx
    if(trace){
 3b5:	85 f6                	test   %esi,%esi
 3b7:	75 23                	jne    3dc <fifo+0xdc>
  for(i = 0; i < n; i++){
 3b9:	83 c7 04             	add    $0x4,%edi
 3bc:	39 7d b4             	cmp    %edi,-0x4c(%ebp)
 3bf:	75 bf                	jne    380 <fifo+0x80>
}
 3c1:	8b 45 a8             	mov    -0x58(%ebp),%eax
 3c4:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3c7:	5b                   	pop    %ebx
 3c8:	5e                   	pop    %esi
 3c9:	5f                   	pop    %edi
 3ca:	5d                   	pop    %ebp
 3cb:	c3                   	ret
 3cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(trace){
 3d0:	8b 75 08             	mov    0x8(%ebp),%esi
      if(fr[j] == refs[i]){ hit = 1; break; }
 3d3:	ba 01 00 00 00       	mov    $0x1,%edx
    if(trace){
 3d8:	85 f6                	test   %esi,%esi
 3da:	74 dd                	je     3b9 <fifo+0xb9>
      printf(1, "%d : [", refs[i]);
 3dc:	83 ec 04             	sub    $0x4,%esp
 3df:	89 55 a4             	mov    %edx,-0x5c(%ebp)
 3e2:	51                   	push   %ecx
 3e3:	68 ed 0d 00 00       	push   $0xded
 3e8:	6a 01                	push   $0x1
 3ea:	e8 71 06 00 00       	call   a60 <printf>
        printf(1, "%s%d", j ? " " : "", fr[j]);
 3ef:	83 c4 10             	add    $0x10,%esp
 3f2:	8b 4d c0             	mov    -0x40(%ebp),%ecx
 3f5:	89 5d a0             	mov    %ebx,-0x60(%ebp)
 3f8:	8b 75 ac             	mov    -0x54(%ebp),%esi
 3fb:	b8 68 0e 00 00       	mov    $0xe68,%eax
 400:	31 db                	xor    %ebx,%ebx
 402:	eb 0d                	jmp    411 <fifo+0x111>
 404:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 408:	8b 4c 9d c0          	mov    -0x40(%ebp,%ebx,4),%ecx
 40c:	b8 c8 0d 00 00       	mov    $0xdc8,%eax
 411:	51                   	push   %ecx
      for(j = 0; j < nf; j++)
 412:	83 c3 01             	add    $0x1,%ebx
        printf(1, "%s%d", j ? " " : "", fr[j]);
 415:	50                   	push   %eax
 416:	68 f4 0d 00 00       	push   $0xdf4
 41b:	6a 01                	push   $0x1
 41d:	e8 3e 06 00 00       	call   a60 <printf>
      for(j = 0; j < nf; j++)
 422:	83 c4 10             	add    $0x10,%esp
 425:	39 de                	cmp    %ebx,%esi
 427:	75 df                	jne    408 <fifo+0x108>
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
 429:	8b 45 a4             	mov    -0x5c(%ebp),%eax
 42c:	ba ca 0d 00 00       	mov    $0xdca,%edx
 431:	8b 5d a0             	mov    -0x60(%ebp),%ebx
 434:	85 c0                	test   %eax,%eax
 436:	b8 ce 0d 00 00       	mov    $0xdce,%eax
 43b:	0f 45 c2             	cmovne %edx,%eax
 43e:	83 ec 04             	sub    $0x4,%esp
 441:	50                   	push   %eax
 442:	68 f9 0d 00 00       	push   $0xdf9
 447:	6a 01                	push   $0x1
 449:	e8 12 06 00 00       	call   a60 <printf>
 44e:	83 c4 10             	add    $0x10,%esp
 451:	e9 63 ff ff ff       	jmp    3b9 <fifo+0xb9>
    printf(1, "\nFIFO trace (%d frames)\n", nf);
 456:	83 ec 04             	sub    $0x4,%esp
 459:	ff 75 ac             	push   -0x54(%ebp)
 45c:	68 d4 0d 00 00       	push   $0xdd4
 461:	6a 01                	push   $0x1
 463:	e8 f8 05 00 00       	call   a60 <printf>
 468:	83 c4 10             	add    $0x10,%esp
 46b:	e9 ef fe ff ff       	jmp    35f <fifo+0x5f>

00000470 <lru>:
{
 470:	55                   	push   %ebp
 471:	89 e5                	mov    %esp,%ebp
 473:	57                   	push   %edi
 474:	56                   	push   %esi
 475:	53                   	push   %ebx
 476:	8d 5d 98             	lea    -0x68(%ebp),%ebx
 479:	83 ec 7c             	sub    $0x7c,%esp
 47c:	89 55 8c             	mov    %edx,-0x74(%ebp)
 47f:	89 45 90             	mov    %eax,-0x70(%ebp)
 482:	89 c8                	mov    %ecx,%eax
  for(i = 0; i < nf; i++){
 484:	31 c9                	xor    %ecx,%ecx
 486:	eb 18                	jmp    4a0 <lru+0x30>
 488:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 48f:	00 
 490:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 497:	00 
 498:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 49f:	00 
    fr[i] = -1;
 4a0:	c7 04 8b ff ff ff ff 	movl   $0xffffffff,(%ebx,%ecx,4)
    last[i] = -1;
 4a7:	89 cf                	mov    %ecx,%edi
 4a9:	c7 44 8d c0 ff ff ff 	movl   $0xffffffff,-0x40(%ebp,%ecx,4)
 4b0:	ff 
  for(i = 0; i < nf; i++){
 4b1:	83 c1 01             	add    $0x1,%ecx
 4b4:	39 c8                	cmp    %ecx,%eax
 4b6:	75 e8                	jne    4a0 <lru+0x30>
  if(trace)
 4b8:	8b 75 08             	mov    0x8(%ebp),%esi
 4bb:	85 f6                	test   %esi,%esi
 4bd:	0f 85 6a 01 00 00    	jne    62d <lru+0x1bd>
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
 4c3:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%ebp)
 4ca:	31 f6                	xor    %esi,%esi
 4cc:	89 4d 80             	mov    %ecx,-0x80(%ebp)
 4cf:	90                   	nop
      if(fr[j] == refs[i]){
 4d0:	8b 45 90             	mov    -0x70(%ebp),%eax
 4d3:	8b 14 b0             	mov    (%eax,%esi,4),%edx
    for(j = 0; j < nf; j++){
 4d6:	31 c0                	xor    %eax,%eax
 4d8:	eb 09                	jmp    4e3 <lru+0x73>
 4da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
 4e0:	83 c0 01             	add    $0x1,%eax
      if(fr[j] == refs[i]){
 4e3:	39 14 83             	cmp    %edx,(%ebx,%eax,4)
 4e6:	0f 84 14 01 00 00    	je     600 <lru+0x190>
    for(j = 0; j < nf; j++){
 4ec:	39 c7                	cmp    %eax,%edi
 4ee:	75 f0                	jne    4e0 <lru+0x70>
      faults++;
 4f0:	83 45 88 01          	addl   $0x1,-0x78(%ebp)
      for(j = 0; j < nf; j++)
 4f4:	31 c0                	xor    %eax,%eax
 4f6:	eb 0b                	jmp    503 <lru+0x93>
 4f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4ff:	00 
 500:	83 c0 01             	add    $0x1,%eax
        if(fr[j] == -1){ slot = j; break; }
 503:	83 3c 83 ff          	cmpl   $0xffffffff,(%ebx,%eax,4)
 507:	74 50                	je     559 <lru+0xe9>
      for(j = 0; j < nf; j++)
 509:	39 c7                	cmp    %eax,%edi
 50b:	75 f3                	jne    500 <lru+0x90>
        slot = 0;
 50d:	31 c0                	xor    %eax,%eax
        for(j = 1; j < nf; j++)
 50f:	83 7d 80 01          	cmpl   $0x1,-0x80(%ebp)
 513:	74 44                	je     559 <lru+0xe9>
        oldest = last[0];
 515:	8b 45 c0             	mov    -0x40(%ebp),%eax
 518:	89 55 84             	mov    %edx,-0x7c(%ebp)
        for(j = 1; j < nf; j++)
 51b:	b9 01 00 00 00       	mov    $0x1,%ecx
        oldest = last[0];
 520:	89 45 94             	mov    %eax,-0x6c(%ebp)
        slot = 0;
 523:	31 c0                	xor    %eax,%eax
 525:	8b 55 94             	mov    -0x6c(%ebp),%edx
 528:	89 75 94             	mov    %esi,-0x6c(%ebp)
 52b:	eb 16                	jmp    543 <lru+0xd3>
 52d:	8d 76 00             	lea    0x0(%esi),%esi
 530:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 537:	00 
 538:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 53f:	00 
        for(j = 1; j < nf; j++)
 540:	83 c1 01             	add    $0x1,%ecx
          if(last[j] < oldest){ oldest = last[j]; slot = j; }
 543:	8b 74 8d c0          	mov    -0x40(%ebp,%ecx,4),%esi
 547:	39 d6                	cmp    %edx,%esi
 549:	0f 4c d6             	cmovl  %esi,%edx
 54c:	0f 4c c1             	cmovl  %ecx,%eax
        for(j = 1; j < nf; j++)
 54f:	39 f9                	cmp    %edi,%ecx
 551:	75 ed                	jne    540 <lru+0xd0>
 553:	8b 55 84             	mov    -0x7c(%ebp),%edx
 556:	8b 75 94             	mov    -0x6c(%ebp),%esi
    if(trace){
 559:	8b 4d 08             	mov    0x8(%ebp),%ecx
      fr[slot] = refs[i];
 55c:	89 54 85 98          	mov    %edx,-0x68(%ebp,%eax,4)
      last[slot] = i;
 560:	89 74 85 c0          	mov    %esi,-0x40(%ebp,%eax,4)
    hit = 0;
 564:	c7 45 94 00 00 00 00 	movl   $0x0,-0x6c(%ebp)
    if(trace){
 56b:	85 c9                	test   %ecx,%ecx
 56d:	0f 84 a3 00 00 00    	je     616 <lru+0x1a6>
      printf(1, "%d : [", refs[i]);
 573:	83 ec 04             	sub    $0x4,%esp
 576:	52                   	push   %edx
 577:	68 ed 0d 00 00       	push   $0xded
 57c:	6a 01                	push   $0x1
 57e:	e8 dd 04 00 00       	call   a60 <printf>
        printf(1, "%s%d", j ? " " : "", fr[j]);
 583:	83 c4 10             	add    $0x10,%esp
 586:	8b 4d 98             	mov    -0x68(%ebp),%ecx
 589:	89 75 84             	mov    %esi,-0x7c(%ebp)
 58c:	ba 68 0e 00 00       	mov    $0xe68,%edx
 591:	31 f6                	xor    %esi,%esi
 593:	eb 0e                	jmp    5a3 <lru+0x133>
 595:	8d 76 00             	lea    0x0(%esi),%esi
      for(j = 0; j < nf; j++)
 598:	83 c6 01             	add    $0x1,%esi
        printf(1, "%s%d", j ? " " : "", fr[j]);
 59b:	ba c8 0d 00 00       	mov    $0xdc8,%edx
 5a0:	8b 0c b3             	mov    (%ebx,%esi,4),%ecx
 5a3:	51                   	push   %ecx
 5a4:	52                   	push   %edx
 5a5:	68 f4 0d 00 00       	push   $0xdf4
 5aa:	6a 01                	push   $0x1
 5ac:	e8 af 04 00 00       	call   a60 <printf>
      for(j = 0; j < nf; j++)
 5b1:	83 c4 10             	add    $0x10,%esp
 5b4:	39 fe                	cmp    %edi,%esi
 5b6:	75 e0                	jne    598 <lru+0x128>
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
 5b8:	8b 45 94             	mov    -0x6c(%ebp),%eax
 5bb:	ba ca 0d 00 00       	mov    $0xdca,%edx
 5c0:	8b 75 84             	mov    -0x7c(%ebp),%esi
 5c3:	85 c0                	test   %eax,%eax
 5c5:	b8 ce 0d 00 00       	mov    $0xdce,%eax
 5ca:	0f 45 c2             	cmovne %edx,%eax
 5cd:	83 ec 04             	sub    $0x4,%esp
  for(i = 0; i < n; i++){
 5d0:	83 c6 01             	add    $0x1,%esi
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
 5d3:	50                   	push   %eax
 5d4:	68 f9 0d 00 00       	push   $0xdf9
 5d9:	6a 01                	push   $0x1
 5db:	e8 80 04 00 00       	call   a60 <printf>
 5e0:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < n; i++){
 5e3:	39 75 8c             	cmp    %esi,-0x74(%ebp)
 5e6:	0f 85 e4 fe ff ff    	jne    4d0 <lru+0x60>
}
 5ec:	8b 45 88             	mov    -0x78(%ebp),%eax
 5ef:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5f2:	5b                   	pop    %ebx
 5f3:	5e                   	pop    %esi
 5f4:	5f                   	pop    %edi
 5f5:	5d                   	pop    %ebp
 5f6:	c3                   	ret
 5f7:	90                   	nop
 5f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5ff:	00 
    if(trace){
 600:	8b 4d 08             	mov    0x8(%ebp),%ecx
      last[slot] = i;
 603:	89 74 85 c0          	mov    %esi,-0x40(%ebp,%eax,4)
        hit = 1;
 607:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%ebp)
    if(trace){
 60e:	85 c9                	test   %ecx,%ecx
 610:	0f 85 5d ff ff ff    	jne    573 <lru+0x103>
  for(i = 0; i < n; i++){
 616:	83 c6 01             	add    $0x1,%esi
 619:	39 75 8c             	cmp    %esi,-0x74(%ebp)
 61c:	0f 85 ae fe ff ff    	jne    4d0 <lru+0x60>
}
 622:	8b 45 88             	mov    -0x78(%ebp),%eax
 625:	8d 65 f4             	lea    -0xc(%ebp),%esp
 628:	5b                   	pop    %ebx
 629:	5e                   	pop    %esi
 62a:	5f                   	pop    %edi
 62b:	5d                   	pop    %ebp
 62c:	c3                   	ret
    printf(1, "\nLRU trace (%d frames)\n", nf);
 62d:	83 ec 04             	sub    $0x4,%esp
 630:	51                   	push   %ecx
 631:	89 4d 94             	mov    %ecx,-0x6c(%ebp)
 634:	68 ff 0d 00 00       	push   $0xdff
 639:	6a 01                	push   $0x1
 63b:	e8 20 04 00 00       	call   a60 <printf>
 640:	8b 4d 94             	mov    -0x6c(%ebp),%ecx
 643:	83 c4 10             	add    $0x10,%esp
 646:	e9 78 fe ff ff       	jmp    4c3 <lru+0x53>
 64b:	66 90                	xchg   %ax,%ax
 64d:	66 90                	xchg   %ax,%ax
 64f:	66 90                	xchg   %ax,%ax
 651:	66 90                	xchg   %ax,%ax
 653:	66 90                	xchg   %ax,%ax
 655:	66 90                	xchg   %ax,%ax
 657:	66 90                	xchg   %ax,%ax
 659:	66 90                	xchg   %ax,%ax
 65b:	66 90                	xchg   %ax,%ax
 65d:	66 90                	xchg   %ax,%ax
 65f:	90                   	nop

00000660 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 660:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 661:	31 c0                	xor    %eax,%eax
{
 663:	89 e5                	mov    %esp,%ebp
 665:	53                   	push   %ebx
 666:	8b 4d 08             	mov    0x8(%ebp),%ecx
 669:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 66c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 670:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 674:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 677:	83 c0 01             	add    $0x1,%eax
 67a:	84 d2                	test   %dl,%dl
 67c:	75 f2                	jne    670 <strcpy+0x10>
    ;
  return os;
}
 67e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 681:	89 c8                	mov    %ecx,%eax
 683:	c9                   	leave
 684:	c3                   	ret
 685:	8d 76 00             	lea    0x0(%esi),%esi
 688:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 68f:	00 

00000690 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 690:	55                   	push   %ebp
 691:	89 e5                	mov    %esp,%ebp
 693:	53                   	push   %ebx
 694:	8b 55 08             	mov    0x8(%ebp),%edx
 697:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 69a:	0f b6 02             	movzbl (%edx),%eax
 69d:	84 c0                	test   %al,%al
 69f:	75 2d                	jne    6ce <strcmp+0x3e>
 6a1:	eb 4a                	jmp    6ed <strcmp+0x5d>
 6a3:	eb 1b                	jmp    6c0 <strcmp+0x30>
 6a5:	8d 76 00             	lea    0x0(%esi),%esi
 6a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6af:	00 
 6b0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6b7:	00 
 6b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6bf:	00 
 6c0:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 6c4:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 6c7:	84 c0                	test   %al,%al
 6c9:	74 15                	je     6e0 <strcmp+0x50>
 6cb:	83 c1 01             	add    $0x1,%ecx
 6ce:	0f b6 19             	movzbl (%ecx),%ebx
 6d1:	38 c3                	cmp    %al,%bl
 6d3:	74 eb                	je     6c0 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 6d5:	29 d8                	sub    %ebx,%eax
}
 6d7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 6da:	c9                   	leave
 6db:	c3                   	ret
 6dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 6e0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 6e4:	31 c0                	xor    %eax,%eax
 6e6:	29 d8                	sub    %ebx,%eax
}
 6e8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 6eb:	c9                   	leave
 6ec:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 6ed:	0f b6 19             	movzbl (%ecx),%ebx
 6f0:	31 c0                	xor    %eax,%eax
 6f2:	eb e1                	jmp    6d5 <strcmp+0x45>
 6f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 6f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6ff:	00 

00000700 <strlen>:

uint
strlen(const char *s)
{
 700:	55                   	push   %ebp
 701:	89 e5                	mov    %esp,%ebp
 703:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 706:	80 3a 00             	cmpb   $0x0,(%edx)
 709:	74 15                	je     720 <strlen+0x20>
 70b:	31 c0                	xor    %eax,%eax
 70d:	8d 76 00             	lea    0x0(%esi),%esi
 710:	83 c0 01             	add    $0x1,%eax
 713:	89 c1                	mov    %eax,%ecx
 715:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 719:	75 f5                	jne    710 <strlen+0x10>
    ;
  return n;
}
 71b:	89 c8                	mov    %ecx,%eax
 71d:	5d                   	pop    %ebp
 71e:	c3                   	ret
 71f:	90                   	nop
  for(n = 0; s[n]; n++)
 720:	31 c9                	xor    %ecx,%ecx
}
 722:	5d                   	pop    %ebp
 723:	89 c8                	mov    %ecx,%eax
 725:	c3                   	ret
 726:	66 90                	xchg   %ax,%ax
 728:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 72f:	00 

00000730 <memset>:

void*
memset(void *dst, int c, uint n)
{
 730:	55                   	push   %ebp
 731:	89 e5                	mov    %esp,%ebp
 733:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 734:	8b 4d 10             	mov    0x10(%ebp),%ecx
 737:	8b 45 0c             	mov    0xc(%ebp),%eax
 73a:	8b 7d 08             	mov    0x8(%ebp),%edi
 73d:	fc                   	cld
 73e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 740:	8b 45 08             	mov    0x8(%ebp),%eax
 743:	8b 7d fc             	mov    -0x4(%ebp),%edi
 746:	c9                   	leave
 747:	c3                   	ret
 748:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 74f:	00 

00000750 <strchr>:

char*
strchr(const char *s, char c)
{
 750:	55                   	push   %ebp
 751:	89 e5                	mov    %esp,%ebp
 753:	8b 45 08             	mov    0x8(%ebp),%eax
 756:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 75a:	0f b6 10             	movzbl (%eax),%edx
 75d:	84 d2                	test   %dl,%dl
 75f:	75 1a                	jne    77b <strchr+0x2b>
 761:	eb 25                	jmp    788 <strchr+0x38>
 763:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 768:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 76f:	00 
 770:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 774:	83 c0 01             	add    $0x1,%eax
 777:	84 d2                	test   %dl,%dl
 779:	74 0d                	je     788 <strchr+0x38>
    if(*s == c)
 77b:	38 d1                	cmp    %dl,%cl
 77d:	75 f1                	jne    770 <strchr+0x20>
      return (char*)s;
  return 0;
}
 77f:	5d                   	pop    %ebp
 780:	c3                   	ret
 781:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 788:	31 c0                	xor    %eax,%eax
}
 78a:	5d                   	pop    %ebp
 78b:	c3                   	ret
 78c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000790 <gets>:

char*
gets(char *buf, int max)
{
 790:	55                   	push   %ebp
 791:	89 e5                	mov    %esp,%ebp
 793:	57                   	push   %edi
 794:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 795:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 798:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 799:	31 db                	xor    %ebx,%ebx
{
 79b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 79e:	eb 27                	jmp    7c7 <gets+0x37>
    cc = read(0, &c, 1);
 7a0:	83 ec 04             	sub    $0x4,%esp
 7a3:	6a 01                	push   $0x1
 7a5:	57                   	push   %edi
 7a6:	6a 00                	push   $0x0
 7a8:	e8 3e 01 00 00       	call   8eb <read>
    if(cc < 1)
 7ad:	83 c4 10             	add    $0x10,%esp
 7b0:	85 c0                	test   %eax,%eax
 7b2:	7e 1d                	jle    7d1 <gets+0x41>
      break;
    buf[i++] = c;
 7b4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 7b8:	8b 55 08             	mov    0x8(%ebp),%edx
 7bb:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 7bf:	3c 0a                	cmp    $0xa,%al
 7c1:	74 1d                	je     7e0 <gets+0x50>
 7c3:	3c 0d                	cmp    $0xd,%al
 7c5:	74 19                	je     7e0 <gets+0x50>
  for(i=0; i+1 < max; ){
 7c7:	89 de                	mov    %ebx,%esi
 7c9:	83 c3 01             	add    $0x1,%ebx
 7cc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 7cf:	7c cf                	jl     7a0 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 7d1:	8b 45 08             	mov    0x8(%ebp),%eax
 7d4:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 7d8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 7db:	5b                   	pop    %ebx
 7dc:	5e                   	pop    %esi
 7dd:	5f                   	pop    %edi
 7de:	5d                   	pop    %ebp
 7df:	c3                   	ret
  buf[i] = '\0';
 7e0:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 7e3:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 7e5:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 7e9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 7ec:	5b                   	pop    %ebx
 7ed:	5e                   	pop    %esi
 7ee:	5f                   	pop    %edi
 7ef:	5d                   	pop    %ebp
 7f0:	c3                   	ret
 7f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 7f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 7ff:	00 

00000800 <stat>:

int
stat(const char *n, struct stat *st)
{
 800:	55                   	push   %ebp
 801:	89 e5                	mov    %esp,%ebp
 803:	56                   	push   %esi
 804:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 805:	83 ec 08             	sub    $0x8,%esp
 808:	6a 00                	push   $0x0
 80a:	ff 75 08             	push   0x8(%ebp)
 80d:	e8 01 01 00 00       	call   913 <open>
  if(fd < 0)
 812:	83 c4 10             	add    $0x10,%esp
 815:	85 c0                	test   %eax,%eax
 817:	78 27                	js     840 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 819:	83 ec 08             	sub    $0x8,%esp
 81c:	ff 75 0c             	push   0xc(%ebp)
 81f:	89 c3                	mov    %eax,%ebx
 821:	50                   	push   %eax
 822:	e8 04 01 00 00       	call   92b <fstat>
  close(fd);
 827:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 82a:	89 c6                	mov    %eax,%esi
  close(fd);
 82c:	e8 ca 00 00 00       	call   8fb <close>
  return r;
 831:	83 c4 10             	add    $0x10,%esp
}
 834:	8d 65 f8             	lea    -0x8(%ebp),%esp
 837:	89 f0                	mov    %esi,%eax
 839:	5b                   	pop    %ebx
 83a:	5e                   	pop    %esi
 83b:	5d                   	pop    %ebp
 83c:	c3                   	ret
 83d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 840:	be ff ff ff ff       	mov    $0xffffffff,%esi
 845:	eb ed                	jmp    834 <stat+0x34>
 847:	90                   	nop
 848:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 84f:	00 

00000850 <atoi>:

int
atoi(const char *s)
{
 850:	55                   	push   %ebp
 851:	89 e5                	mov    %esp,%ebp
 853:	53                   	push   %ebx
 854:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 857:	0f be 02             	movsbl (%edx),%eax
 85a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 85d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 860:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 865:	77 2e                	ja     895 <atoi+0x45>
 867:	eb 17                	jmp    880 <atoi+0x30>
 869:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 870:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 877:	00 
 878:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 87f:	00 
    n = n*10 + *s++ - '0';
 880:	83 c2 01             	add    $0x1,%edx
 883:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 886:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 88a:	0f be 02             	movsbl (%edx),%eax
 88d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 890:	80 fb 09             	cmp    $0x9,%bl
 893:	76 eb                	jbe    880 <atoi+0x30>
  return n;
}
 895:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 898:	89 c8                	mov    %ecx,%eax
 89a:	c9                   	leave
 89b:	c3                   	ret
 89c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000008a0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 8a0:	55                   	push   %ebp
 8a1:	89 e5                	mov    %esp,%ebp
 8a3:	57                   	push   %edi
 8a4:	8b 45 10             	mov    0x10(%ebp),%eax
 8a7:	8b 55 08             	mov    0x8(%ebp),%edx
 8aa:	56                   	push   %esi
 8ab:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 8ae:	85 c0                	test   %eax,%eax
 8b0:	7e 13                	jle    8c5 <memmove+0x25>
 8b2:	01 d0                	add    %edx,%eax
  dst = vdst;
 8b4:	89 d7                	mov    %edx,%edi
 8b6:	66 90                	xchg   %ax,%ax
 8b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 8bf:	00 
    *dst++ = *src++;
 8c0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 8c1:	39 f8                	cmp    %edi,%eax
 8c3:	75 fb                	jne    8c0 <memmove+0x20>
  return vdst;
}
 8c5:	5e                   	pop    %esi
 8c6:	89 d0                	mov    %edx,%eax
 8c8:	5f                   	pop    %edi
 8c9:	5d                   	pop    %ebp
 8ca:	c3                   	ret

000008cb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 8cb:	b8 01 00 00 00       	mov    $0x1,%eax
 8d0:	cd 40                	int    $0x40
 8d2:	c3                   	ret

000008d3 <exit>:
SYSCALL(exit)
 8d3:	b8 02 00 00 00       	mov    $0x2,%eax
 8d8:	cd 40                	int    $0x40
 8da:	c3                   	ret

000008db <wait>:
SYSCALL(wait)
 8db:	b8 03 00 00 00       	mov    $0x3,%eax
 8e0:	cd 40                	int    $0x40
 8e2:	c3                   	ret

000008e3 <pipe>:
SYSCALL(pipe)
 8e3:	b8 04 00 00 00       	mov    $0x4,%eax
 8e8:	cd 40                	int    $0x40
 8ea:	c3                   	ret

000008eb <read>:
SYSCALL(read)
 8eb:	b8 05 00 00 00       	mov    $0x5,%eax
 8f0:	cd 40                	int    $0x40
 8f2:	c3                   	ret

000008f3 <write>:
SYSCALL(write)
 8f3:	b8 10 00 00 00       	mov    $0x10,%eax
 8f8:	cd 40                	int    $0x40
 8fa:	c3                   	ret

000008fb <close>:
SYSCALL(close)
 8fb:	b8 15 00 00 00       	mov    $0x15,%eax
 900:	cd 40                	int    $0x40
 902:	c3                   	ret

00000903 <kill>:
SYSCALL(kill)
 903:	b8 06 00 00 00       	mov    $0x6,%eax
 908:	cd 40                	int    $0x40
 90a:	c3                   	ret

0000090b <exec>:
SYSCALL(exec)
 90b:	b8 07 00 00 00       	mov    $0x7,%eax
 910:	cd 40                	int    $0x40
 912:	c3                   	ret

00000913 <open>:
SYSCALL(open)
 913:	b8 0f 00 00 00       	mov    $0xf,%eax
 918:	cd 40                	int    $0x40
 91a:	c3                   	ret

0000091b <mknod>:
SYSCALL(mknod)
 91b:	b8 11 00 00 00       	mov    $0x11,%eax
 920:	cd 40                	int    $0x40
 922:	c3                   	ret

00000923 <unlink>:
SYSCALL(unlink)
 923:	b8 12 00 00 00       	mov    $0x12,%eax
 928:	cd 40                	int    $0x40
 92a:	c3                   	ret

0000092b <fstat>:
SYSCALL(fstat)
 92b:	b8 08 00 00 00       	mov    $0x8,%eax
 930:	cd 40                	int    $0x40
 932:	c3                   	ret

00000933 <link>:
SYSCALL(link)
 933:	b8 13 00 00 00       	mov    $0x13,%eax
 938:	cd 40                	int    $0x40
 93a:	c3                   	ret

0000093b <mkdir>:
SYSCALL(mkdir)
 93b:	b8 14 00 00 00       	mov    $0x14,%eax
 940:	cd 40                	int    $0x40
 942:	c3                   	ret

00000943 <chdir>:
SYSCALL(chdir)
 943:	b8 09 00 00 00       	mov    $0x9,%eax
 948:	cd 40                	int    $0x40
 94a:	c3                   	ret

0000094b <dup>:
SYSCALL(dup)
 94b:	b8 0a 00 00 00       	mov    $0xa,%eax
 950:	cd 40                	int    $0x40
 952:	c3                   	ret

00000953 <getpid>:
SYSCALL(getpid)
 953:	b8 0b 00 00 00       	mov    $0xb,%eax
 958:	cd 40                	int    $0x40
 95a:	c3                   	ret

0000095b <sbrk>:
SYSCALL(sbrk)
 95b:	b8 0c 00 00 00       	mov    $0xc,%eax
 960:	cd 40                	int    $0x40
 962:	c3                   	ret

00000963 <sleep>:
SYSCALL(sleep)
 963:	b8 0d 00 00 00       	mov    $0xd,%eax
 968:	cd 40                	int    $0x40
 96a:	c3                   	ret

0000096b <uptime>:
SYSCALL(uptime)
 96b:	b8 0e 00 00 00       	mov    $0xe,%eax
 970:	cd 40                	int    $0x40
 972:	c3                   	ret

00000973 <vmprint>:

// Assignment 9 system calls
SYSCALL(vmprint)
 973:	b8 16 00 00 00       	mov    $0x16,%eax
 978:	cd 40                	int    $0x40
 97a:	c3                   	ret

0000097b <getfaults>:
SYSCALL(getfaults)
 97b:	b8 17 00 00 00       	mov    $0x17,%eax
 980:	cd 40                	int    $0x40
 982:	c3                   	ret
 983:	66 90                	xchg   %ax,%ax
 985:	66 90                	xchg   %ax,%ax
 987:	66 90                	xchg   %ax,%ax
 989:	66 90                	xchg   %ax,%ax
 98b:	66 90                	xchg   %ax,%ax
 98d:	66 90                	xchg   %ax,%ax
 98f:	66 90                	xchg   %ax,%ax
 991:	66 90                	xchg   %ax,%ax
 993:	66 90                	xchg   %ax,%ax
 995:	66 90                	xchg   %ax,%ax
 997:	66 90                	xchg   %ax,%ax
 999:	66 90                	xchg   %ax,%ax
 99b:	66 90                	xchg   %ax,%ax
 99d:	66 90                	xchg   %ax,%ax
 99f:	90                   	nop

000009a0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 9a0:	55                   	push   %ebp
 9a1:	89 e5                	mov    %esp,%ebp
 9a3:	57                   	push   %edi
 9a4:	56                   	push   %esi
 9a5:	53                   	push   %ebx
 9a6:	89 cb                	mov    %ecx,%ebx
 9a8:	83 ec 3c             	sub    $0x3c,%esp
 9ab:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 9ae:	85 d2                	test   %edx,%edx
 9b0:	0f 89 9a 00 00 00    	jns    a50 <printint+0xb0>
 9b6:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 9ba:	0f 84 90 00 00 00    	je     a50 <printint+0xb0>
    neg = 1;
    x = -xx;
 9c0:	f7 da                	neg    %edx
    neg = 1;
 9c2:	b8 01 00 00 00       	mov    $0x1,%eax
 9c7:	89 45 c0             	mov    %eax,-0x40(%ebp)
 9ca:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 9cc:	31 f6                	xor    %esi,%esi
 9ce:	66 90                	xchg   %ax,%ax
 9d0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 9d7:	00 
 9d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 9df:	00 
  do{
    buf[i++] = digits[x % base];
 9e0:	89 c8                	mov    %ecx,%eax
 9e2:	31 d2                	xor    %edx,%edx
 9e4:	89 f7                	mov    %esi,%edi
 9e6:	f7 f3                	div    %ebx
 9e8:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 9eb:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 9ed:	0f b6 92 40 10 00 00 	movzbl 0x1040(%edx),%edx
  }while((x /= base) != 0);
 9f4:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 9f6:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 9fa:	73 e4                	jae    9e0 <printint+0x40>
  if(neg)
 9fc:	8b 45 c0             	mov    -0x40(%ebp),%eax
 9ff:	85 c0                	test   %eax,%eax
 a01:	74 07                	je     a0a <printint+0x6a>
    buf[i++] = '-';
 a03:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 a08:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 a0a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 a0e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 a11:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 a14:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 a18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 a1f:	00 
    putc(fd, buf[i]);
 a20:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 a23:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 a26:	83 ee 01             	sub    $0x1,%esi
 a29:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 a2c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 a2f:	6a 01                	push   $0x1
 a31:	50                   	push   %eax
 a32:	57                   	push   %edi
 a33:	e8 bb fe ff ff       	call   8f3 <write>
  while(--i >= 0)
 a38:	83 c4 10             	add    $0x10,%esp
 a3b:	39 f3                	cmp    %esi,%ebx
 a3d:	75 e1                	jne    a20 <printint+0x80>
}
 a3f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 a42:	5b                   	pop    %ebx
 a43:	5e                   	pop    %esi
 a44:	5f                   	pop    %edi
 a45:	5d                   	pop    %ebp
 a46:	c3                   	ret
 a47:	90                   	nop
 a48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 a4f:	00 
  neg = 0;
 a50:	31 c0                	xor    %eax,%eax
 a52:	e9 70 ff ff ff       	jmp    9c7 <printint+0x27>
 a57:	90                   	nop
 a58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 a5f:	00 

00000a60 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 a60:	55                   	push   %ebp
 a61:	89 e5                	mov    %esp,%ebp
 a63:	57                   	push   %edi
 a64:	56                   	push   %esi
 a65:	53                   	push   %ebx
 a66:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 a69:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 a6c:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 a6f:	0f b6 13             	movzbl (%ebx),%edx
 a72:	83 c3 01             	add    $0x1,%ebx
 a75:	84 d2                	test   %dl,%dl
 a77:	0f 84 a0 00 00 00    	je     b1d <printf+0xbd>
 a7d:	8d 45 10             	lea    0x10(%ebp),%eax
 a80:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 a83:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 a86:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 a89:	eb 28                	jmp    ab3 <printf+0x53>
 a8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 a90:	83 ec 04             	sub    $0x4,%esp
 a93:	8d 45 e7             	lea    -0x19(%ebp),%eax
 a96:	88 55 e7             	mov    %dl,-0x19(%ebp)
  for(i = 0; fmt[i]; i++){
 a99:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 a9c:	6a 01                	push   $0x1
 a9e:	50                   	push   %eax
 a9f:	56                   	push   %esi
 aa0:	e8 4e fe ff ff       	call   8f3 <write>
  for(i = 0; fmt[i]; i++){
 aa5:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 aa9:	83 c4 10             	add    $0x10,%esp
 aac:	84 d2                	test   %dl,%dl
 aae:	74 6d                	je     b1d <printf+0xbd>
    c = fmt[i] & 0xff;
 ab0:	0f b6 c2             	movzbl %dl,%eax
      if(c == '%'){
 ab3:	83 f8 25             	cmp    $0x25,%eax
 ab6:	75 d8                	jne    a90 <printf+0x30>
  for(i = 0; fmt[i]; i++){
 ab8:	0f b6 13             	movzbl (%ebx),%edx
 abb:	84 d2                	test   %dl,%dl
 abd:	74 5e                	je     b1d <printf+0xbd>
    c = fmt[i] & 0xff;
 abf:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 ac2:	80 fa 25             	cmp    $0x25,%dl
 ac5:	0f 84 25 01 00 00    	je     bf0 <printf+0x190>
 acb:	83 e8 63             	sub    $0x63,%eax
 ace:	83 f8 15             	cmp    $0x15,%eax
 ad1:	77 0d                	ja     ae0 <printf+0x80>
 ad3:	ff 24 85 e8 0f 00 00 	jmp    *0xfe8(,%eax,4)
 ada:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 ae0:	83 ec 04             	sub    $0x4,%esp
 ae3:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 ae6:	88 55 d0             	mov    %dl,-0x30(%ebp)
        ap++;
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 ae9:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 aed:	6a 01                	push   $0x1
 aef:	51                   	push   %ecx
 af0:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 af3:	56                   	push   %esi
 af4:	e8 fa fd ff ff       	call   8f3 <write>
        putc(fd, c);
 af9:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 afd:	83 c4 0c             	add    $0xc,%esp
 b00:	88 55 e7             	mov    %dl,-0x19(%ebp)
 b03:	6a 01                	push   $0x1
 b05:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 b08:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 b09:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 b0c:	56                   	push   %esi
 b0d:	e8 e1 fd ff ff       	call   8f3 <write>
  for(i = 0; fmt[i]; i++){
 b12:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 b16:	83 c4 10             	add    $0x10,%esp
 b19:	84 d2                	test   %dl,%dl
 b1b:	75 93                	jne    ab0 <printf+0x50>
      }
      state = 0;
    }
  }
}
 b1d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 b20:	5b                   	pop    %ebx
 b21:	5e                   	pop    %esi
 b22:	5f                   	pop    %edi
 b23:	5d                   	pop    %ebp
 b24:	c3                   	ret
 b25:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 b28:	83 ec 0c             	sub    $0xc,%esp
 b2b:	8b 17                	mov    (%edi),%edx
 b2d:	b9 10 00 00 00       	mov    $0x10,%ecx
 b32:	89 f0                	mov    %esi,%eax
 b34:	6a 00                	push   $0x0
 b36:	e8 65 fe ff ff       	call   9a0 <printint>
  for(i = 0; fmt[i]; i++){
 b3b:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 b3f:	83 c3 02             	add    $0x2,%ebx
 b42:	83 c4 10             	add    $0x10,%esp
 b45:	84 d2                	test   %dl,%dl
 b47:	74 d4                	je     b1d <printf+0xbd>
        ap++;
 b49:	83 c7 04             	add    $0x4,%edi
 b4c:	e9 5f ff ff ff       	jmp    ab0 <printf+0x50>
 b51:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 b58:	8b 07                	mov    (%edi),%eax
        ap++;
 b5a:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 b5d:	85 c0                	test   %eax,%eax
 b5f:	0f 84 9b 00 00 00    	je     c00 <printf+0x1a0>
        while(*s != 0){
 b65:	0f b6 10             	movzbl (%eax),%edx
 b68:	84 d2                	test   %dl,%dl
 b6a:	0f 84 a2 00 00 00    	je     c12 <printf+0x1b2>
 b70:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 b73:	89 c7                	mov    %eax,%edi
 b75:	89 d0                	mov    %edx,%eax
 b77:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 b7a:	89 fb                	mov    %edi,%ebx
 b7c:	8d 7d e7             	lea    -0x19(%ebp),%edi
 b7f:	90                   	nop
  write(fd, &c, 1);
 b80:	83 ec 04             	sub    $0x4,%esp
 b83:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 b86:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 b89:	6a 01                	push   $0x1
 b8b:	57                   	push   %edi
 b8c:	56                   	push   %esi
 b8d:	e8 61 fd ff ff       	call   8f3 <write>
        while(*s != 0){
 b92:	0f b6 03             	movzbl (%ebx),%eax
 b95:	83 c4 10             	add    $0x10,%esp
 b98:	84 c0                	test   %al,%al
 b9a:	75 e4                	jne    b80 <printf+0x120>
 b9c:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 b9f:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 ba3:	83 c3 02             	add    $0x2,%ebx
 ba6:	84 d2                	test   %dl,%dl
 ba8:	0f 85 d5 fe ff ff    	jne    a83 <printf+0x23>
 bae:	e9 6a ff ff ff       	jmp    b1d <printf+0xbd>
 bb3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 bb8:	83 ec 0c             	sub    $0xc,%esp
 bbb:	8b 17                	mov    (%edi),%edx
 bbd:	b9 0a 00 00 00       	mov    $0xa,%ecx
 bc2:	89 f0                	mov    %esi,%eax
 bc4:	6a 01                	push   $0x1
 bc6:	e8 d5 fd ff ff       	call   9a0 <printint>
  for(i = 0; fmt[i]; i++){
 bcb:	e9 6b ff ff ff       	jmp    b3b <printf+0xdb>
        putc(fd, *ap);
 bd0:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 bd2:	83 ec 04             	sub    $0x4,%esp
 bd5:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 bd8:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 bdb:	6a 01                	push   $0x1
 bdd:	51                   	push   %ecx
 bde:	56                   	push   %esi
 bdf:	e8 0f fd ff ff       	call   8f3 <write>
 be4:	e9 52 ff ff ff       	jmp    b3b <printf+0xdb>
 be9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 bf0:	83 ec 04             	sub    $0x4,%esp
 bf3:	88 55 e7             	mov    %dl,-0x19(%ebp)
 bf6:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 bf9:	6a 01                	push   $0x1
 bfb:	e9 08 ff ff ff       	jmp    b08 <printf+0xa8>
          s = "(null)";
 c00:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 c03:	b8 28 00 00 00       	mov    $0x28,%eax
 c08:	bf 7c 0e 00 00       	mov    $0xe7c,%edi
 c0d:	e9 65 ff ff ff       	jmp    b77 <printf+0x117>
  for(i = 0; fmt[i]; i++){
 c12:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 c16:	83 c3 02             	add    $0x2,%ebx
 c19:	84 d2                	test   %dl,%dl
 c1b:	0f 85 8f fe ff ff    	jne    ab0 <printf+0x50>
 c21:	e9 f7 fe ff ff       	jmp    b1d <printf+0xbd>
 c26:	66 90                	xchg   %ax,%ax
 c28:	66 90                	xchg   %ax,%ax
 c2a:	66 90                	xchg   %ax,%ax
 c2c:	66 90                	xchg   %ax,%ax
 c2e:	66 90                	xchg   %ax,%ax
 c30:	66 90                	xchg   %ax,%ax
 c32:	66 90                	xchg   %ax,%ax
 c34:	66 90                	xchg   %ax,%ax
 c36:	66 90                	xchg   %ax,%ax
 c38:	66 90                	xchg   %ax,%ax
 c3a:	66 90                	xchg   %ax,%ax
 c3c:	66 90                	xchg   %ax,%ax
 c3e:	66 90                	xchg   %ax,%ax

00000c40 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 c40:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c41:	a1 6c 13 00 00       	mov    0x136c,%eax
{
 c46:	89 e5                	mov    %esp,%ebp
 c48:	57                   	push   %edi
 c49:	56                   	push   %esi
 c4a:	53                   	push   %ebx
 c4b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 c4e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c51:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 c58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 c5f:	00 
 c60:	89 c2                	mov    %eax,%edx
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c62:	8b 00                	mov    (%eax),%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c64:	39 ca                	cmp    %ecx,%edx
 c66:	73 30                	jae    c98 <free+0x58>
 c68:	39 c1                	cmp    %eax,%ecx
 c6a:	72 04                	jb     c70 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c6c:	39 c2                	cmp    %eax,%edx
 c6e:	72 f0                	jb     c60 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 c70:	8b 73 fc             	mov    -0x4(%ebx),%esi
 c73:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 c76:	39 f8                	cmp    %edi,%eax
 c78:	74 36                	je     cb0 <free+0x70>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 c7a:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 c7d:	8b 42 04             	mov    0x4(%edx),%eax
 c80:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 c83:	39 f1                	cmp    %esi,%ecx
 c85:	74 40                	je     cc7 <free+0x87>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 c87:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 c89:	5b                   	pop    %ebx
  freep = p;
 c8a:	89 15 6c 13 00 00    	mov    %edx,0x136c
}
 c90:	5e                   	pop    %esi
 c91:	5f                   	pop    %edi
 c92:	5d                   	pop    %ebp
 c93:	c3                   	ret
 c94:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c98:	39 c2                	cmp    %eax,%edx
 c9a:	72 c4                	jb     c60 <free+0x20>
 c9c:	39 c1                	cmp    %eax,%ecx
 c9e:	73 c0                	jae    c60 <free+0x20>
  if(bp + bp->s.size == p->s.ptr){
 ca0:	8b 73 fc             	mov    -0x4(%ebx),%esi
 ca3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 ca6:	39 f8                	cmp    %edi,%eax
 ca8:	75 d0                	jne    c7a <free+0x3a>
 caa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp->s.size += p->s.ptr->s.size;
 cb0:	03 70 04             	add    0x4(%eax),%esi
 cb3:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 cb6:	8b 02                	mov    (%edx),%eax
 cb8:	8b 00                	mov    (%eax),%eax
 cba:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 cbd:	8b 42 04             	mov    0x4(%edx),%eax
 cc0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 cc3:	39 f1                	cmp    %esi,%ecx
 cc5:	75 c0                	jne    c87 <free+0x47>
    p->s.size += bp->s.size;
 cc7:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 cca:	89 15 6c 13 00 00    	mov    %edx,0x136c
    p->s.size += bp->s.size;
 cd0:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 cd3:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 cd6:	89 0a                	mov    %ecx,(%edx)
}
 cd8:	5b                   	pop    %ebx
 cd9:	5e                   	pop    %esi
 cda:	5f                   	pop    %edi
 cdb:	5d                   	pop    %ebp
 cdc:	c3                   	ret
 cdd:	8d 76 00             	lea    0x0(%esi),%esi

00000ce0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 ce0:	55                   	push   %ebp
 ce1:	89 e5                	mov    %esp,%ebp
 ce3:	57                   	push   %edi
 ce4:	56                   	push   %esi
 ce5:	53                   	push   %ebx
 ce6:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 ce9:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 cec:	8b 15 6c 13 00 00    	mov    0x136c,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 cf2:	8d 78 07             	lea    0x7(%eax),%edi
 cf5:	c1 ef 03             	shr    $0x3,%edi
 cf8:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 cfb:	85 d2                	test   %edx,%edx
 cfd:	0f 84 8d 00 00 00    	je     d90 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 d03:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 d05:	8b 48 04             	mov    0x4(%eax),%ecx
 d08:	39 f9                	cmp    %edi,%ecx
 d0a:	73 64                	jae    d70 <malloc+0x90>
  if(nu < 4096)
 d0c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 d11:	39 df                	cmp    %ebx,%edi
 d13:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 d16:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 d1d:	eb 0a                	jmp    d29 <malloc+0x49>
 d1f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 d20:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 d22:	8b 48 04             	mov    0x4(%eax),%ecx
 d25:	39 f9                	cmp    %edi,%ecx
 d27:	73 47                	jae    d70 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 d29:	89 c2                	mov    %eax,%edx
 d2b:	39 05 6c 13 00 00    	cmp    %eax,0x136c
 d31:	75 ed                	jne    d20 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 d33:	83 ec 0c             	sub    $0xc,%esp
 d36:	56                   	push   %esi
 d37:	e8 1f fc ff ff       	call   95b <sbrk>
  if(p == (char*)-1)
 d3c:	83 c4 10             	add    $0x10,%esp
 d3f:	83 f8 ff             	cmp    $0xffffffff,%eax
 d42:	74 1c                	je     d60 <malloc+0x80>
  hp->s.size = nu;
 d44:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 d47:	83 ec 0c             	sub    $0xc,%esp
 d4a:	83 c0 08             	add    $0x8,%eax
 d4d:	50                   	push   %eax
 d4e:	e8 ed fe ff ff       	call   c40 <free>
  return freep;
 d53:	8b 15 6c 13 00 00    	mov    0x136c,%edx
      if((p = morecore(nunits)) == 0)
 d59:	83 c4 10             	add    $0x10,%esp
 d5c:	85 d2                	test   %edx,%edx
 d5e:	75 c0                	jne    d20 <malloc+0x40>
        return 0;
  }
}
 d60:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 d63:	31 c0                	xor    %eax,%eax
}
 d65:	5b                   	pop    %ebx
 d66:	5e                   	pop    %esi
 d67:	5f                   	pop    %edi
 d68:	5d                   	pop    %ebp
 d69:	c3                   	ret
 d6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 d70:	39 cf                	cmp    %ecx,%edi
 d72:	74 4c                	je     dc0 <malloc+0xe0>
        p->s.size -= nunits;
 d74:	29 f9                	sub    %edi,%ecx
 d76:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 d79:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 d7c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 d7f:	89 15 6c 13 00 00    	mov    %edx,0x136c
}
 d85:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 d88:	83 c0 08             	add    $0x8,%eax
}
 d8b:	5b                   	pop    %ebx
 d8c:	5e                   	pop    %esi
 d8d:	5f                   	pop    %edi
 d8e:	5d                   	pop    %ebp
 d8f:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 d90:	c7 05 6c 13 00 00 70 	movl   $0x1370,0x136c
 d97:	13 00 00 
    base.s.size = 0;
 d9a:	b8 70 13 00 00       	mov    $0x1370,%eax
    base.s.ptr = freep = prevp = &base;
 d9f:	c7 05 70 13 00 00 70 	movl   $0x1370,0x1370
 da6:	13 00 00 
    base.s.size = 0;
 da9:	c7 05 74 13 00 00 00 	movl   $0x0,0x1374
 db0:	00 00 00 
    if(p->s.size >= nunits){
 db3:	e9 54 ff ff ff       	jmp    d0c <malloc+0x2c>
 db8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 dbf:	00 
        prevp->s.ptr = p->s.ptr;
 dc0:	8b 08                	mov    (%eax),%ecx
 dc2:	89 0a                	mov    %ecx,(%edx)
 dc4:	eb b9                	jmp    d7f <malloc+0x9f>
